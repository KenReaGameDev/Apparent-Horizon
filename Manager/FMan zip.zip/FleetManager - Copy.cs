using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Linq;
using System.Linq.Expressions;
using System.Linq;
using System.Threading;

// 1.5.2014
// TODO: 
// Implement Loading of actual ships into game.
// Maybe load all ships to outside of map -- then clone!
// DESPAWN SHIPS ON CHANGE!
// Generate Fleets based on ships
// Begin AI Behavior algorithms.

// Extended:: Continue to multithread things like Asteroid Generation!
// Fleet Manager hangs out in..
public class FleetManager : MonoBehaviour {	
	
	public int[] fleetSeed = new int[10]; 
	public int systemID = 0;
	public string[] factionNames;
	public int factionCount;
	List<Fleet> allFleets = new List<Fleet>();
	// Holds the AiShip for every Ship.
	public List<Ship> allShips = new List<Ship>(); 
	// For Preloading all Factions ship specs. 
	static public List<XDocument> allShipSpecs = new List<XDocument>();
	static public string resourcePath;
	
	// Thread Safe Variables.
	private readonly object syncLock = new object();
	private readonly object xmlLock = new object();
	
	public static int threads;
	public ConcurrentQueue<AiShip> ThreadQueue = new ConcurrentQueue<AiShip>();
	
	int fleetUpdate = 0;
	int fleetShuffle = 0;
	// List that has the fleets.
	// Fleets them-selves are a list of ships in the fleet.
	// fleet ship 0 == fleet leader. This is determined by strongest ship in fleet.
	// fleet leader cannot change until leader is dead.
	
	// BUG: This is being called too many times.
	public void FleetManager_New (int[] seed, int inID)
	{
		Debug.Log("Fleet Manager has been Created");
		fleetSeed = seed;
		systemID = inID;	
		resourcePath = Application.dataPath;
		allShipSpecs = FactionTracker.Instance.GetAllFactionShipDatas();
		allShips = new List<Ship>();
		allFleets = new List<Fleet>();
		// If system is new...
		Run();
		
		// If system is old...
		// Load old system information!
	}
	
	// Called during system creation.
	void Run () {
		
		// any player in the system will be in the scene. Otherwise they will not. 
		foreach (PlayerShip p in GetComponent<Game>().GetPlayerShipList())
		{
			p.currentSystemSeed = systemID;
			if (p.currentSystemSeed == systemID)
				allShips.Add(p);
			PlayerShip test = p.getShipModel().GetComponent<PlayerShip>();
			test.currentSystemSeed = systemID;
			Debug.Log("ListShip Test System Seed: " + p.currentSystemSeed);
			Debug.Log ("ShipModelTest System Seed: " + test.currentSystemSeed);
		}
		
		CreateShips_Init();
		if (threads < 1)
			CreateFleets_Init();	
	}
	
	void Start() {
		allShipSpecs = FactionTracker.Instance.GetAllFactionShipDatas();
	}
	
	// Update is called once per frame
	public void Update () {
		
		if (fleetUpdate > 30)
		{
			try
			{
				foreach(Fleet fl in allFleets)
					fl.UpdateFleet();
				fleetUpdate = 0;
			}
			catch
			{
				fleetUpdate = 30;	
			}
		}
		
		if (fleetShuffle > 900)
		{
			Shuffle<Fleet>(allFleets);
		}		
		
		++fleetUpdate;
		++fleetShuffle;
		
		// Possibly Obsolete Code
		// Maybe Multithread this -- Not sure yet.
//		foreach (AiShip updateShips in allShips)
//		{
//			// Create non Mono-Behavior Function Update if I want to multithread.
//			//updateShips.Update();	
//		}
		
	}
	
	public void Shuffle<T>(IList<T> list)  
	{  
	    System.Random rng = new System.Random();  
	    int n = list.Count;  
	    while (n > 1) {  
	        n--;  
	        int k = rng.Next(n + 1);  
	        T value = list[k];  
	        list[k] = list[n];  
	        list[n] = value;  
	    }  
	}
	
	void CreateShips_Init()
	{
		Debug.Log("###########################ENTERING CREATE SHIPS ###########################");
		// Difficult is first 4 numbers of seed.
		int difficulty = 0;		
		for (int i = 0; i < 4; i++)
		{
    		difficulty += fleetSeed[i] * System.Convert.ToInt32(System.Math.Pow(10, 4-i-1));
		}
		difficulty = System.Math.Abs(difficulty);	
	
		// TODO: If player gets warp targeter, can potentially reroll difficulty based on parameters.. Will Add Later
		
		// [NOTE]
		// Use difficulty to determine type of ships. The higher the difficulty, the larger the amount of ships
		// and higher the chance of them being stronger.
		// Less than 5 ships should be all scouts.
		
		// int because we don't want any fractions.
		int shipAmount = difficulty / 15;
		Debug.Log("Ship Amount " + shipAmount);
		factionNames = FactionTracker.Instance.GetFactionNames();
		factionCount = FactionTracker.Instance.GetFactionCount();
		//double[] probabilities = = CreateProbabilities
		
		for (int createShips = 0; createShips < shipAmount; createShips++)
		{			
			//Debug.Log("ITERATION: " + createShips);
			AiShip ship = new AiShip();
			Thread shipGenThread = new Thread(() => ShipGenerationThread(ship, difficulty, factionCount));
			//TODO: BUG: BLOWS UP GAME			
			shipGenThread.Start();			
		}	
		while (threads > 0)
		{
			Time.timeScale = 0.0f;
			continue;
		}
		Time.timeScale = 1.0f;
		
		// Safely update List with new Model Attached List.
		List<Ship> tempList = new List<Ship>();
		
		int cnt = 0;
		foreach (Ship aiship in allShips)
		{
			cnt++;			
		}
		
		Debug.Log("Ai Ships Ship Count in List: " + cnt);
		
		LoadShips:
		bool shipsLoaded;
		try
		{
			
			// List safe Changes also.
			foreach (Ship ship in allShips)
			{
				if (ship.Equals(new AiShip()))
				{
					Debug.Log("Adding AI Ship");
					AiShip holdship = (AiShip)ship;
					holdship.setShipModelLoad(holdship);
					tempList.Add(holdship);
					Debug.Log("TempList Count: " + tempList.Count);
				}
				else
				{
					Debug.Log("Adding Player Ship");
					tempList.Add(ship);	
				}
			}
			shipsLoaded = true;
		}
		catch
		{
			shipsLoaded = false;
		}
		if (!shipsLoaded)
			goto LoadShips;
		
		allShips = tempList;
		Debug.Log("Ships in allShip List using COUNT: "+ allShips.Count());
	}
	
	//BUG: Thread may not be returning to 0. This will cause hang. 
	void ShipGenerationThread(AiShip thisShip, int inDifficulty, int inFactionCount)
	{

		threads++;
		// Determine the Faction
		thisShip = ShipFactionDeterminer(thisShip);
		Debug.Log("Ship Faction: " + thisShip.getFaction());
		thisShip = ShipShipDeterminer(thisShip, inDifficulty);
		// MAKE THREAD SAFE LATER.
		thisShip.ID = allShips.Count();
		allShips.Add(thisShip);		
		threads--;

	}
	
	void SetFleet_Player(PlayerShip ship)
	{
		ship = ship.getShipModel().GetComponent<PlayerShip>();
		//Debug.Log("Fleeting Ship : " + ship.getShipModel().name + " - Faction " + ship.getFaction() + " / Threat " + ship.GetAttributes().threatLevel);
		// Check if the ship is a fleet leader
		// If this ship has no fleet leader then...
		if (ship.getFleetLeader() == null)
		{
			Debug.Log("Leader is null");
			//FactionTracker.Factions tempFaction = new FactionTracker.Factions();
			// If there is such a faction, it returns it based on name.
			//tempFaction = FactionTracker.Instance.GetFaction(ship.getFaction());
			
			// Check for fleets with faction tag being the same.
			foreach (Fleet fl in allFleets)
			{
				Debug.Log("There is a fleet");
				//Debug.Log("FLEET FACTION: " + fl.faction + " / SHIP FACTION: " + ship.faction);
				// Adds ship to fleet if all requirements are met.
				if (fl.faction.Equals(ship.getFaction()) && fl.fleet.Count < 10)//tempFaction.maxShipsInFleet)
				{		
					Debug.Log("ADDED TO FLEET");
					ship.setFleetLeader(fl.fleetLeader);
					Debug.Log("Fleet Leader is now " + ship.getFleetLeader());
					if (ship.getFleetLeader() == null)
						Debug.Log("Ship has no fleet leader Bug. Leader should be " + fl.fleetLeader.getShipModel().name);
					
					ship.SetMyFleet(fl);
					fl.pFleet.Add((PlayerShip)ship);
					// TODO: Determine threat elsewhere because foreach doesn't allow modification of variables.
					//fl.threat += ship.getAttributes().threatLevel;
					break;	
				}
			}

			
			if (ship.getFleetLeader() != null)
			{					
				Fleet fl = ship.GetMyFleet();	
				if (fl == null)
				{
					Debug.Log("Error in setting accel code");
					Debug.Log("No Fleet: " + ship.getShipModel());
					Debug.Log("However Leader is: " + ship.getFleetLeader());
				}
				float accel = ship.GetAttributes().maxAcceleration;					
				
				if (fl.minimumSpeed > ship.GetAttributes().maxSpeed)
					fl.minimumSpeed = ship.GetAttributes().maxSpeed;
				
				if (fl.minimumAccel > accel)
					fl.minimumAccel = accel;
				
				return;
			}
			
			Debug.Log("Creating new Fleet");
			// If no fleet matches criteria or no fleets exist, create new fleet.
			Fleet newFleet = new Fleet(this, ship);
			newFleet.fleet = new List<AiShip>();
			newFleet.pFleet = new List<PlayerShip>();
			newFleet.pFleet.Add(ship);
			newFleet.faction = ship.getFaction();
			Debug.Log(ship.getShipModel().name);
			Debug.Log(newFleet.fleetLeader);
			newFleet.threat += ship.GetAttributes().threatLevel;
			newFleet.minimumSpeed = ship.GetAttributes().maxSpeed;
			newFleet.minimumAccel = ship.GetAttributes().maxAcceleration;
			Debug.Log("Ship Mass: " + ship.GetAttributes().mass + " and MaxAccell: " + ship.GetAttributes().maxAcceleration);
			Debug.Log("New Fleet MACC = " + newFleet.minimumAccel + " and MinSpeed = " + newFleet.minimumSpeed);
			//newFleet.position = ship.transform.position;
			ship.SetIsFleetLeader(true, ship);
			newFleet.position = ship.getShipModel().transform.position;
			ship.setFleetLeader(newFleet.fleetLeader);
			ship.SetMyFleet(newFleet);
			allFleets.Add(newFleet);
			Debug.Log("Reaches End of Loop ITERATION");
		}
		
		if (ship.GetMyFleet() == null)
		{
			Debug.Log("No ship was ever added to fleet");
			Debug.Log("Faction is: " + ship.getFaction());
			Debug.Log("Ship is: " + ship.getShipModel());
			Debug.Log("Fleet Leader Is: " + ship.getFleetLeader());
		}		
	}
	
	// Set fleet for AI ship.
	void SetFleet_Ai(AiShip ship)
	{
		// BUG: Error if no ship. Unknown Cause.
		ship = ship.getShipModel().GetComponent<AiShip>();
		
		//Debug.Log("Fleeting Ship : " + ship.getShipModel().name + " - Faction " + ship.getFaction() + " / Threat " + ship.GetAttributes().threatLevel);
		// Check if the ship is a fleet leader
		// If this ship has no fleet leader then...
		if (ship.getFleetLeader() == null)
		{
			//FactionTracker.Factions tempFaction = new FactionTracker.Factions();
			// If there is such a faction, it returns it based on name.
			//tempFaction = FactionTracker.Instance.GetFaction(ship.getFaction());
			
			// Check for fleets with faction tag being the same.
			foreach (Fleet fl in allFleets)
			{
				Debug.Log("There is a fleet");
				//Debug.Log("FLEET FACTION: " + fl.faction + " / SHIP FACTION: " + ship.faction);
				// Adds ship to fleet if all requirements are met.
				if (fl.faction.Equals(ship.getFaction()) && fl.fleet.Count < 20)//tempFaction.maxShipsInFleet)
				{		
					Debug.Log("ADDED TO FLEET");
					ship.setFleetLeader(fl.fleetLeader);
					Debug.Log("Fleet Leader is now " + ship.getFleetLeader());
					if (ship.getFleetLeader() == null)
						Debug.Log("Ship has no fleet leader Bug. Leader should be " + fl.fleetLeader.getShipModel().name);
					
					ship.SetMyFleet(fl);
					fl.fleet.Add((AiShip)ship);

					// TODO: Determine threat elsewhere because foreach doesn't allow modification of variables.
					//fl.threat += ship.getAttributes().threatLevel;
					break;	
				}
			}

			
			if (ship.getFleetLeader() != null)
			{					
				Fleet fl = ship.GetMyFleet();	
				if (fl == null)
				{
					Debug.Log("Error in setting accel code");
					Debug.Log("No Fleet: " + ship.getShipModel());
					Debug.Log("However Leader is: " + ship.getFleetLeader());
				}
				float accel = ship.GetAttributes().maxAcceleration;					
				
				if (fl.minimumSpeed > ship.GetAttributes().maxSpeed)
					fl.minimumSpeed = ship.GetAttributes().maxSpeed;
				
				if (fl.minimumAccel > accel)
					fl.minimumAccel = accel;
				
				fl.threat += ship.GetAttributes().threatLevel;
				
				return;
			}
			
			Debug.Log("Creating new Fleet");
			// If no fleet matches criteria or no fleets exist, create new fleet.
			Fleet newFleet = new Fleet(this, ship);
			newFleet.fleet = new List<AiShip>();
			newFleet.pFleet = new List<PlayerShip>();
			newFleet.fleet.Add(ship);
			newFleet.faction = ship.getFaction();
			Debug.Log(ship.getShipModel().name);
			Debug.Log("Fleet - Fleet Faction: " + newFleet.faction);
			Debug.Log("Fleet - Fleet Leader: " + newFleet.fleetLeader);
			newFleet.threat += ship.GetAttributes().threatLevel;
			newFleet.minimumSpeed = ship.GetAttributes().maxSpeed;
			newFleet.minimumAccel = ship.GetAttributes().maxAcceleration;
			Debug.Log("Ship Mass: " + ship.GetAttributes().mass + " and MaxAccell: " + ship.GetAttributes().maxAcceleration);
			Debug.Log("New Fleet MACC = " + newFleet.minimumAccel + " and MinSpeed = " + newFleet.minimumSpeed);
			//newFleet.position = ship.transform.position;
			ship.SetIsFleetLeader(true, ship);
			//ship.getShipModel().GetComponent<AiShip>().determiner = new BehaviorDeterminerAiShip();
			newFleet.position = ship.getShipModel().transform.position;
			ship.setFleetLeader(newFleet.fleetLeader);
			ship.SetMyFleet(newFleet);
			allFleets.Add(newFleet);
			Debug.Log("Reaches End of Loop ITERATION");
		}
		
		if (ship.GetMyFleet() == null)
		{
			Debug.Log("No ship was ever added to fleet");
			Debug.Log("Faction is: " + ship.getFaction());
			Debug.Log("Ship is: " + ship.getShipModel());
			Debug.Log("Fleet Leader Is: " + ship.getFleetLeader());
		}				
	}
	// TODO: Fix fleets. 
	// Determine fleets once per system creation.
	void CreateFleets_Init() {
		
		Debug.Log("Creating Fleets of Ships  ASHIPS COUNT "  + allShips.Count );
		
		foreach (Ship ship in allShips)
		{
			AiShip ai;
			PlayerShip pl;
			
			if (ship.Equals(new AiShip()))
				SetFleet_Ai((AiShip)ship);
			else
				SetFleet_Player((PlayerShip)ship);
				
			
		}
		
		// Check if is fleet leader.
		foreach (Ship fl in allShips)
		{			
			//Debug.Log("Fleet Leader for: " + fl.modelName + " is " + fl.getFleetLeader().modelName);
		}
		
	}
	
	public void UpdateFleet_LeaderLoss(AiShip ship)
	{
			
	}
	
	public void UpdateFleet_ShipLoss(AiShip ship)
	{
		Fleet fl = ship.GetMyFleet();
		float accel = ship.GetAttributes().mass * ship.GetAttributes().maxAcceleration;
		
	}
	// Loads old ships and fleets based on xml or other loading file structure.
	void PopulateSystem_Load () {
		// Use this if it's an old system, loaded from file. 
	}
	
	// During game.savesystem, game will call this to save fleets in system.
	void SaveSystem () {
		
	}
	
	// Unload system and delete before creating new as to clean up garbage. 
	void UnloadSystem () {
		
	}
	
	// Determine Ship based on Parabolic Probabilities
	AiShip ShipShipDeterminer (AiShip inShip, int inDifficulty) {
		
		int factionIndex = FactionTracker.Instance.GetFactionIndex(inShip.getFaction());	
		
		// Locked Variables
		int shipCount = 0;
		string shipname = "";
		
		// Determine how many ships faction has.
		lock(xmlLock)
		{
			shipCount = allShipSpecs[factionIndex].Descendants("Attributes").Count();
		}
		
		double[] probabilities = CreateProbabilitiesShipType(shipCount, inDifficulty, true);
		
		// Use PickFaction to pick the Ship (Code Reuse)
		int shipIndex = PickShip(probabilities);
		//Debug.Log("SHIP INDEX: " + shipIndex);
	
		// Get ship from XDocument via ship index.
		lock (xmlLock)
		{
			var node = allShipSpecs[factionIndex].Descendants("Attributes").Skip(shipIndex).Take(1);
			foreach (var nodes in node)
			{
				shipname = (string)nodes.Element("name");	
			}	
		}	
		
		//Debug.Log("Ship Picked: " + shipname + " Faction Picked: " + inShip.getFaction());
		// Load attributes for said ship then return ship.
		// Minus 1 due to player not being faction for AiShips.
		inShip.setAttributes(Ships.LoadAiShip(inShip.getFaction(),shipname, factionIndex));
		inShip.currentSystemSeed = systemID;
		return inShip;		
	}
	
	// Determines Majority.
	// Picks faction for passed in ship.
	// http://stackoverflow.com/questions/9330394/how-to-pick-an-item-by-its-probability
	AiShip ShipFactionDeterminer (AiShip inShip) {
				
		double probability = 0;
		double majorityProbability = 0;
		double[] probabilities = new double[factionCount];
		
		// Determines Majority.
		// Picks faction for passed in ship.
		// TODO: Use XML file to not use switch, just use enumerated from XML.
		switch (this.fleetSeed[4])
		{
			// Mixed no Pirates
			case 0:
				//Debug.Log("No Pirates");	
				probability = 100 / (factionCount - 1);						
				probabilities = CreateProbabilities(probabilities, probability, 1);
				inShip.setFaction(factionNames[PickFaction(probabilities)]);
				
			break;
			
			// Mixed with Pirates
			case 1:
				//Debug.Log("Mix with Pirates");
				probability = 100 / factionCount;
				probabilities = CreateProbabilities(probabilities, probability, probability);
				inShip.setFaction(factionNames[PickFaction(probabilities)]);
				
			break;
			
			// Majority Pirates
			case 2:
				//Debug.Log("Majority Pirates");
				probability = 100 / (factionCount * 2);
				majorityProbability = probability * (factionCount + 1);
				probabilities = CreateProbabilities("Pirates", probabilities, probability, majorityProbability);
				inShip.setFaction(factionNames[PickFaction(probabilities)]);
				
			break;
			
			// Majority Rainbow
			case 3:
				//Debug.Log("Majority Rainbow");
				probability = 100 / (factionCount * 2);
				majorityProbability = probability * (factionCount + 1);
				probabilities = CreateProbabilities("Rainbow Surfers", probabilities, probability, majorityProbability);
				inShip.setFaction(factionNames[PickFaction(probabilities)]);
				
			break;
			
			// Majority Sidrat
			case 4:
				//Debug.Log("Majority Sidrat");
				probability = 100 / (factionCount * 2);
				majorityProbability = probability * (factionCount + 1);
				probabilities = CreateProbabilities("Sidrat", probabilities, probability, majorityProbability);
				inShip.setFaction(factionNames[PickFaction(probabilities)]);
				
			break;
			
			// Majority Goons
			case 5:
				//Debug.Log("Majority Goons");
				probability = 100 / (factionCount * 2);
				majorityProbability = probability * (factionCount + 1);
				probabilities = CreateProbabilities("The Goons", probabilities, probability, majorityProbability);
				inShip.setFaction(factionNames[PickFaction(probabilities)]);
				
			break;
			
			// Majority Strashok
			case 6:
				//Debug.Log("Majority Strashok");
				probability = 100 / (factionCount * 2);
				majorityProbability = probability * (factionCount + 1);
				probabilities = CreateProbabilities("Soyuz Strashok", probabilities, probability, majorityProbability);
				inShip.setFaction(factionNames[PickFaction(probabilities)]);
				
			break;
			
			// Majority Semper
			case 7:
				//Debug.Log("Majority Semper");
				probability = 100 / (factionCount * 2);
				majorityProbability = probability * (factionCount + 1);
				probabilities = CreateProbabilities("Semper Solus", probabilities, probability, majorityProbability);
				inShip.setFaction(factionNames[PickFaction(probabilities)]);
				
			break;
			
			// Random Minority Faction
			case 8:
				//Debug.Log("Minority Faction");
				probability = 100 / (factionCount * 2);
				majorityProbability = probability * (factionCount + 1);
				// TODO: Select a random Minority to be the Majority. Or Create One.
				probabilities = CreateProbabilities("Pirates", probabilities, probability, majorityProbability);
				inShip.setFaction(factionNames[PickFaction(probabilities)]);
				
			break;
			
			// Empty
			case 9:
				probability = 0;
			break;
		}
		
		//Debug.Log("INSHIP FACTION: " + inShip.getFaction());
		return inShip;
	}
		
	// Create probabilities for MAJORITY systems
	double[] CreateProbabilities (string inMajority, double[] probabilities, double probability, double majorProbability) 
	{
		for (int index = 0; index < factionCount; ++index)
		{
			if (string.Equals(inMajority, factionNames[index], System.StringComparison.OrdinalIgnoreCase))
				probabilities[index] = majorProbability;
			else
				probabilities[index] = probability;
		}		
		return probabilities;
	}
	
	// Create probabilities for MIXED systems
	double[] CreateProbabilities (double[] probabilities, double probability, double majorProbability) 
	{	
		for (int index = 0; index < factionCount; ++index)
		{
			probabilities[index] = probability;
		}		
		return probabilities;
	}
	
	// No Pirates
	double[] CreateProbabilities (double[] probabilities, double probability, bool pirates) 
	{
		//Debug.Log("No Pirates!");
		for (int index = 0; index < factionCount; ++index)
		{
			if (string.Equals((string)"pirates", factionNames[index], System.StringComparison.OrdinalIgnoreCase))
				probabilities[index] = 0;
			else
				probabilities[index] = probability;
		}		
		return probabilities;
	}
	
	// For Picking Ship.
	// Parabolic Probability Generation Algorithm
	double[] CreateProbabilitiesShipType (int inShipAmount, int inDiffuclty, bool Parabolic) 
	{
		// Gets the ship with the highest probability
		double[] probabilities;
		probabilities = new double[inShipAmount];
		
		//Debug.Log("inShipAmount: " + inShipAmount + " - inDifficulty: " + inDiffuclty);		
		double vertexD = (inShipAmount * inDiffuclty / 9999);
		
		//Debug.Log("Vertex Double: " + vertexD);
		int vertex = (int)System.Math.Round(vertexD, System.MidpointRounding.AwayFromZero);
		//Debug.Log("VERTEX: " + vertex);
		//Debug.Log("Vertex: " + vertex);
		probabilities[vertex] = 50;
		
		// Regular Cases
		if (vertex > 0 && vertex < inShipAmount - 1)
		{
			probabilities = LeftSideParabola(probabilities, vertex, inShipAmount);
			probabilities = RightSideParabola(probabilities, vertex, inShipAmount);
		}		
		
		// Special Cases
		// Nothing on Left
		if (vertex == 0) 
		{
			//Debug.Log("SPECIAL CASE VERTEX IS 0");
			probabilities = RightSideSpecialCase(probabilities, inShipAmount);
		}
		// Nothing on Right
		if (vertex == inShipAmount)
		{
			//Debug.Log("SPECIAL CASE VERTEX IS SHIP AMOUNT");
			probabilities = LeftSideSpecialCase(probabilities, inShipAmount);
		}
		
		for (int i = 0; i < probabilities.Count(); ++i)
		{
			//Debug.Log("Prob " + i + ":" + probabilities[i]);
		}
		return probabilities;
	}
	
	double[] LeftSideParabola(double[] probabilities, int vertex, int inShipAmount)
	{
		//Debug.Log("LEFT SIDE Regular Case");
		int difference = 1;
		if (vertex > 1)
			difference = vertex;
		int high = vertex - 1;
		int low = 0;
		int midpoint = -1;
		int calculations = 0;
		double baseProbability = 25.0 / (double)difference;
		
		if (difference == 1)
		{
			probabilities[0] = 25;	
			return probabilities;	
		}
		
		if (difference % 2 > 0)
		{			
			midpoint = (int)System.Math.Round((double)(difference/2), System.MidpointRounding.AwayFromZero);
			//Debug.Log("Midpoint: " + midpoint);
			probabilities[midpoint - 1] = baseProbability;
		}		
		
		// Should round down. If not force round down.
		calculations = difference / 2;
		
		for (int ndx = 2; ndx < calculations + 2; ++ndx)
		{
			double probabilityMod = (baseProbability / ndx) * 2.0;
			probabilities[high] = baseProbability + probabilityMod;
			probabilities[low] = baseProbability - probabilityMod;
			high -= 1;
			low += 1;
		}
		
		return probabilities;
	}
	
	double[] RightSideParabola(double[] probabilities, int vertex, int inShipAmount)
	{
		//Debug.Log("Right SIDE Regular Case");
		// Right Side of Algorithm
		int difference = 1;
		if (vertex < inShipAmount - 2)
			difference = inShipAmount - vertex + 1;
		
		// Vertex is 0
		int high = vertex + 1;
		int low = inShipAmount - 1;
		int midpoint = -1;
		int calculations = 0;
		double baseProbability = 25.0 / (double)difference;
		
		// Odd numbers have a mid number
		// Handle the possibility of only 1 item on the side.
		if (difference == 1)
		{
			probabilities[inShipAmount - 1] = 25;
			return probabilities;
		}
		
		if (difference % 2 > 0)
		{
			midpoint = (int)System.Math.Round((double)(difference/2), System.MidpointRounding.AwayFromZero);
			probabilities[midpoint - 1] = baseProbability;
		}
		
		// Figure out how many times we are going to calculate		
		calculations = difference / 2;
		
		// Using ndx as my probability modifier, end condition has to be increased based upon this.
		for (int ndx = 2; ndx < calculations + 2; ++ndx)
		{
			double probabilityMod = (baseProbability / ndx) * 2.0;
			probabilities[high] = baseProbability + probabilityMod;
			probabilities[low] = baseProbability - probabilityMod;
			high += 1;
			low -= 1;
		}	
		return probabilities;
	}
	
	// Vertex is 0
	double[] RightSideSpecialCase(double[] probabilities, int inShipAmount)
	{		
		int vertex = 0;
		int difference = inShipAmount - 1;
		//Debug.Log("inShipAmount Special Case: " + inShipAmount);
		double baseProbability = 100.0 / (double)difference;
		//Debug.Log("Base Probability: " + baseProbability); 
		int high = 0;
		// TODO: Check to make sure this is proper.
		int low = inShipAmount - 1;
		int midpoint = -1;
		int calculations = 0;
		
		// Figure out how many times we are going to calculate		
		calculations = difference / 2;
	
		// Using ndx as my probability modifier, end condition has to be increased based upon this.
		for (int ndx = 2; ndx < calculations + 2; ++ndx)
		{
			double probabilityMod = (baseProbability / ndx) * 2.0;
			probabilities[high] = baseProbability + probabilityMod;
			probabilities[low] = baseProbability - probabilityMod;
			high += 1;
			low -= 1;
		}
		
		// Set middile probability if there is an odd number of ships.
		if (difference % 2 == 0)			
		{			
			midpoint = (int)System.Math.Round((double)(difference/2), System.MidpointRounding.AwayFromZero);
			double middleProbability = (probabilities[midpoint+1] + probabilities[midpoint-1]) / 2; 
			probabilities[midpoint] = middleProbability;
		}
		
		// Normalizing to 100.
		int count = probabilities.Count();
		double normal = 0.0f;
		
		// Get total amount that needs to be normalized to 100;
		for (int nrml = 0; nrml < probabilities.Count(); nrml++)
		{
			normal += probabilities[nrml];
		}	
		
		// Cross mulityple to get normal.
		normal = (probabilities[0] * 100) / normal;
		normal = normal / probabilities[0]; 
		
		// Finally normalize all the probabilities.
		for (int nrml2 = 0; nrml2 < probabilities.Count(); nrml2++)
		{
			probabilities[nrml2] *= normal;
		}	
		
		return probabilities;		
	}
	
	// Vertex is Max
	double[] LeftSideSpecialCase(double[] probabilities, int inShipAmount)
	{
		int vertex = inShipAmount - 1;
		int difference = inShipAmount - 1 ;
		double baseProbability = 100.0 / (double)difference;
		int high = vertex;
		// TODO: Check to make sure this is proper.
		int low = 0;
		int midpoint = -1;
		int calculations = 0;

		
		// Figure out how many times we are going to calculate
		calculations = difference / 2;
		// Using ndx as my probability modifier, end condition has to be increased based upon this.
		for (int ndx = 2; ndx < calculations + 2; ++ndx)
		{
			double probabilityMod = (baseProbability / ndx) * 2.0;
			probabilities[high] = baseProbability + probabilityMod;
			probabilities[low] = baseProbability - probabilityMod;
			high -= 1;
			low += 1;
		}

				// Set middile probability if there is an odd number of ships.
		if (difference % 2 == 0)			
		{			
			midpoint = (int)System.Math.Round((double)(difference/2), System.MidpointRounding.AwayFromZero);
			double middleProbability = (probabilities[midpoint+1] + probabilities[midpoint-1]) / 2; 
			probabilities[midpoint] = middleProbability;
		}
		
		// Normalizing to 100.
		int count = probabilities.Count();
		double normal = 0.0f;
		
		// Get total amount that needs to be normalized to 100;
		for (int nrml = 0; nrml < probabilities.Count(); nrml++)
		{
			normal += probabilities[nrml];
		}	
		
		// Cross mulityple to get normal.
		normal = (probabilities[vertex] * 100) / normal;
		normal = normal / probabilities[vertex];  
		
		// Finally normalize all the probabilities.
		for (int nrml2 = 0; nrml2 < probabilities.Count(); nrml2++)
		{
			probabilities[nrml2] *= normal;
		}	
			
		return probabilities;
	}
	// Pick a faction based on probabilities. 
	int PickFaction (double[] probabilities) 
	{
		int count = probabilities.Count();
		double pick = (double)SystemSeed.RandomSeed_Custom(count,99);
		double sum = 0;
		int i=1;
        while(sum < pick) 
		{
        	sum = sum + probabilities[i];
			++i;
			if (i > count - 1)
				break;
        }
		//Debug.Log("Int OUT: " + (i-1));
		return (i-1);
	}
	
	int PickShip(double[] probabilities)
	{
		int count = probabilities.Count();
		string bigstring = "";
		for (int r = 0; r < count; ++r)
		{
			bigstring += "Prob" + r + ": " + probabilities[r];
		}
		
		//Debug.Log(bigstring);
		
		double pick = (double)SystemSeed.RandomSeed_Custom(count,99);
		double sum = 0;
		int i=1;
        while(sum < pick) 
		{
        	sum = sum + probabilities[i];
			++i;
			if (i > count - 1)
				break;
        }
		//Debug.Log("Int OUT: " + (i-1));
		return (i-1);	
	}
	
	public List<Fleet> GetFleetList ()
	{
		return allFleets;
	}
}
